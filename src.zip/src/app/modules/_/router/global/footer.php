<footer>
  <p>footer stuff</p>
</footer>
