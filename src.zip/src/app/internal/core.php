<?php
  $app = new App;
  $app->module('load', false);
  $router = new Pbcrouter;
  $router->load();
?>
